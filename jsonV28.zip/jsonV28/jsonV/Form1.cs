﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace jsonV
{
    public partial class Form1 : Form
    {
        class Auto
        {
            private string marca;
            private string modello;
            private string cavalli;
            private string cilindrata;
            private string anno;
            private int prezzo;
            public string descrizione;
            public bool noleg;
            public string ute;
            public int numg;
            private List<Immagine> img;

            public Auto()
            {
                marca = "Non Presente";
                modello = "Non Presente";
                cavalli = "0";
                cilindrata = "0";
                anno = "0";
                prezzo = 0;
                numg = 0;
                descrizione = "Non Presente";
                noleg = false;
                ute = Utente.user;
                img = new List<Immagine> { new Immagine() }; // Inizializza correttamente la lista di immagini
            }

           

            public string Marca
            {
                get { return marca; }
                set { marca = value; }
            }
            public string Modello
            {
                get { return modello; }
                set { modello = value; }
            }
            public string Cilindrata
            {
                get { return cilindrata; }
                set { cilindrata = value; }
            }
            public string Cavalli
            {
                get { return cavalli; }
                set { cavalli = value; }
            }
            public string Anno
            {
                get { return anno; }
                set { anno = value; }
            }
            public int Prezzo
            {
                get { return prezzo; }
                set { prezzo = value; }
            }
            public int Numg
            {
                get { return numg; }
                set { numg = value; }
            }

            public string Descrizione
            {
                get { return descrizione; }
                set { descrizione = value; }
            }
            public bool Noll
            {
                get { return noleg; }
                set { noleg = value; }
            }
            public string Ute
            {
                get { return ute; }
                set { ute = value; }
            }
            public List<Immagine> Image
            {
                get { return img; }
                set { img = value; }
            }
        }

        class Immagine
        {
            private string img;
            public Immagine()
            {
                img = @"immagini\imgBase.jpeg";
            }
            public string Image
            {
                get { return img; }
                set { img = value; }
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        List<Auto> w = new List<Auto>();
        string[] imgImport;
        bool imgImported = false;
        int contImg = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            deserializza();
            string agg;
            lB1.Items.Clear();
            foreach (Auto a in w)
            {
                agg = a.Marca + "_" + a.Modello;
                lB1.Items.Add(agg);
               
            }
            
        }

        private void deserializza()
        {
            w.Clear();
            string[] righe = File.ReadAllLines("prova.json");

            if (File.Exists("prova.json"))
            {
                foreach (string riga in righe)
                {
                    Auto a = JsonSerializer.Deserialize<Auto>(riga);
                    w.Add(a);
                }
            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            string[] ricerca = lB1.Text.Split('_');
            string marcaCercata = ricerca[0];
            string modelloCercato = ricerca[1];

            foreach (Auto a in w)
            {
                if (a.Marca == marcaCercata && a.Modello == modelloCercato)
                {
                    if(a.noleg == true)
                    {
                        toolStripMenuItem16.Enabled = false;
                        toolStripMenuItem17.Enabled = true;
                        toolStripMenuItem10.Enabled = false;
                        if(a.ute != Utente.user)
                        {
                            toolStripMenuItem17.Enabled = false;
                        }
                    }
                    else
                    {
                        toolStripMenuItem16.Enabled = true;
                        toolStripMenuItem17.Enabled = false;
                        toolStripMenuItem10.Enabled = true;
                    }






                    if (a.Ute ==Utente.user || a.noleg == false)
                    {
                        toolStripMenuItem17.Enabled = true;

                    }
                    else
                    {
                        toolStripMenuItem17.Enabled = false;
                    }
                    string nolleg = "";
                    if (a.Noll == true)
                    {
                        nolleg = "AUTO NOLEGGIATA"+ Environment.NewLine;
                        MessageBox.Show("Auto Noleggiata");
                    }
                   

                    
                    
                        string titolo = a.Marca + " " + a.Modello;
                        string agDesc = "Prezzo:" + a.Prezzo + "€" + Environment.NewLine + "CARATERISTICHE:   " +
                                        " anno: " + a.Anno + "   cilindrata: " + a.Cilindrata + "    cavalli: " + a.Cavalli + Environment.NewLine+nolleg  + "DESCRIZIONE: " + a.Descrizione;
                        textBox1.Text = agDesc;
                        textBox6.Text = titolo;

                        string img = a.Image[contImg].Image;
                        Console.WriteLine("Current Directory: " + Directory.GetCurrentDirectory());
                        Console.WriteLine("Image Path: " + img);

                        try
                        {
                            pictureBox1.Image = Image.FromFile(img);
                        }
                        catch (FileNotFoundException ex)
                        {
                            MessageBox.Show($"File not found: {img}\nException: {ex.Message}");
                        }
                    
                }
            }
        }

        private void pulisci()
        {
            lB1.Items.Clear();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            lB1.Items.Clear();
            deserializza();

            string agg;

            foreach (Auto a in w)
            {
                agg = a.Marca + "_" + a.Modello;
                lB1.Items.Add(agg);
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string JsonString = string.Empty;
            string percorso = "prova.json";
            int cont = 0;

            foreach (Auto a in w)
            {
                if (cont > 0)
                {
                    JsonString += Environment.NewLine;
                }

                JsonString += JsonSerializer.Serialize(a);
                cont++;
            }

            File.WriteAllText(percorso, JsonString);
        }
       
         string destinationFolder = @"immagini";
        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            Auto a1 = new Auto();
           
            try
            {
                a1.Marca = toolStripTextBox1.Text;
                a1.Modello = toolStripTextBox2.Text;
                a1.Cilindrata = toolStripTextBox4.Text;
                a1.Anno = toolStripTextBox5.Text;
                a1.Cavalli = toolStripTextBox3.Text;
                a1.Prezzo = Convert.ToInt32(toolStripTextBox8.Text);
                a1.Descrizione = toolStripTextBox9.Text;
            }
            catch (Exception ex)
            {
                return;

            }
            if (imgImported == true) { 
                a1.Image.Clear();
                foreach (string img in imgImport)
                {
                    Immagine i = new Immagine();
                    //
                    string fileName = Path.GetFileName(img);
                    string destFilePath = Path.Combine(destinationFolder, fileName);

                    File.Copy(img, destFilePath, true); 
                    i.Image = destFilePath;
                    //

                   
                    a1.Image.Add(i);
                }
                imgImported = false;
                

            }
            toolStripTextBox1.Clear();
            toolStripTextBox2.Clear();
            toolStripTextBox3.Clear();
            toolStripTextBox4.Clear();
            toolStripTextBox5.Clear();
            toolStripTextBox8.Clear();
            toolStripTextBox9.Clear();

            w.Add(a1);

            string agg = a1.Marca + "_" + a1.Modello;

            lB1.Items.Add(agg);
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            string[] ell;
            string targetMarca;
            string targetModello;
            try
            {
                ell = lB1.Text.Split('_');
                targetMarca = ell[0];
                targetModello = ell[1];
            }
            catch (Exception ex)
            {
                return;
                
            }
            Auto daRimuovere = null;
            foreach (Auto a in w)
            {
                if (a.Marca == targetMarca && a.Modello == targetModello)
                {
                    daRimuovere = a;
                    
                }
            }

            if (daRimuovere != null)
            {
                w.Remove(daRimuovere);
            }

            lB1.Items.Clear();

            foreach (Auto a in w)
            {
                lB1.Items.Add(a.Marca + "_" + a.Modello);
            }
        }


        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            imgImport = openFileDialog1.FileNames;
            imgImported = true;
        }
        

        private void toolStripMenuItem14_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();

        }












        private void textBox6_TextChanged(object sender, EventArgs e)
        {
        }

        private void toolStripMenuItem12_Click(object sender, EventArgs e)
        {
        }

        private void btnavanti_Click(object sender, EventArgs e)
        {




            string[] ricerca = lB1.Text.Split('_');
            string marcaCercata = ricerca[0];
            string modelloCercato = ricerca[1];

            foreach (Auto a in w)
            {
                if (a.Marca == marcaCercata && a.Modello == modelloCercato)
                {
                    
                    if(contImg < a.Image.Count-1) { 
                    contImg++;
                    }
                    else
                    {
                        contImg = 0;
                    }
                    string img = a.Image[contImg].Image;
                    
                    Console.WriteLine("Current Directory: " + Directory.GetCurrentDirectory());
                    Console.WriteLine("Image Path: " + img);

                    try
                    {
                        pictureBox1.Image = Image.FromFile(img);
                    }
                    catch (FileNotFoundException ex)
                    {
                        MessageBox.Show($"File not found: {img}\nException: {ex.Message}");
                    }
                    break;
                }
            }

        }

        private void btnindietro_Click(object sender, EventArgs e)
        {
            string[] ricerca = lB1.Text.Split('_');
            string marcaCercata = ricerca[0];
            string modelloCercato = ricerca[1];

            foreach (Auto a in w)
            {
                if (a.Marca == marcaCercata && a.Modello == modelloCercato)
                {

                    if (contImg > 0)
                    {
                        contImg--;
                    }
                    else
                    {
                        contImg = a.Image.Count-1;
                    }
                    string img = a.Image[contImg].Image;

                    Console.WriteLine("Current Directory: " + Directory.GetCurrentDirectory());
                    Console.WriteLine("Image Path: " + img);

                    try
                    {
                        pictureBox1.Image = Image.FromFile(img);
                    }
                    catch (FileNotFoundException ex)
                    {
                        MessageBox.Show($"File not found: {img}\nException: {ex.Message}");
                    }
                    break;
                }
            }
        }

        private void toolStripMenuItem16_Click(object sender, EventArgs e)
        {
            string[] ricerca = lB1.Text.Split('_');
            string marcaCercata;
            string modelloCercato;
            try
            {
                marcaCercata = ricerca[0];
                modelloCercato = ricerca[1];
            }
            catch (Exception ex)
            {
                return;


                //consigiato da un solito ignoto  della 4IE mentre in Chiamata su ds pk se il ...... non seleziona la macchina non fa nulla
            }
            int gi;
            try
            {
                 gi = Convert.ToInt32(toolStripTextBox6.Text);
            }
            catch {
                MessageBox.Show("indicare il numero di giorni");
                return; 
            }
            foreach (Auto a in w)
            {
                if (a.Marca == marcaCercata && a.Modello == modelloCercato)
                {
                    a.noleg = true;
                    a.Numg = gi;


                    string titolo = a.Marca + " " + a.Modello;
                    string agDesc = "Prezzo:" + a.Prezzo + "€" + Environment.NewLine + "CARATERISTICHE:   " +
                                    " anno: " + a.Anno + "   cilindrata: " + a.Cilindrata + "    cavalli: " + a.Cavalli + Environment.NewLine + "AUTO NOLEGGIATA"+Environment.NewLine + "DESCRIZIONE: " + a.Descrizione;
                    textBox1.Text = agDesc;
                    textBox6.Text = titolo;

                    string img = a.Image[contImg].Image;
                    Console.WriteLine("Current Directory: " + Directory.GetCurrentDirectory());
                    Console.WriteLine("Image Path: " + img);

                    try
                    {
                        pictureBox1.Image = Image.FromFile(img);
                    }
                    catch (FileNotFoundException ex)
                    {
                        MessageBox.Show($"File not found: {img}\nException: {ex.Message}");
                    }
                    MessageBox.Show("Auto Noleggiata");
                    break;
                }
            }

            lB1.Items.Clear();
            foreach (Auto a in w)
            {
                lB1.Items.Add(a.Marca + "_" + a.Modello);
            }
        }

        int costo;
        private void toolStripMenuItem17_Click(object sender, EventArgs e)
        {
            string[] ricerca;
            string marcaCercata ;
            string modelloCercato;

            try
            {
                ricerca = lB1.Text.Split('_');
                marcaCercata = ricerca[0];
                modelloCercato = ricerca[1];
            }
            catch(Exception ex)
            {
                return;
            }
            
            foreach (Auto a in w)
            {
                if (a.Marca == marcaCercata && a.Modello == modelloCercato)
                {
                    a.noleg = false;
                    costo = a.Numg*a.Prezzo;
                    a.Numg = 0;
                   

                    string titolo = a.Marca + " " + a.Modello;
                    string agDesc = "Prezzo:" + a.Prezzo + "€" + Environment.NewLine + "CARATERISTICHE:   " +
                                    " anno: " + a.Anno + "   cilindrata: " + a.Cilindrata + "    cavalli: " + a.Cavalli + Environment.NewLine + "DESCRIZIONE: " + a.Descrizione;
                    textBox1.Text = agDesc;
                    textBox6.Text = titolo;

                    string img = a.Image[contImg].Image;
                    Console.WriteLine("Current Directory: " + Directory.GetCurrentDirectory());
                    Console.WriteLine("Image Path: " + img);

                    try
                    {
                        pictureBox1.Image = Image.FromFile(img);
                    }
                    catch (FileNotFoundException ex)
                    {
                        MessageBox.Show($"File not found: {img}\nException: {ex.Message}");
                    }
                    break;
                }
            }
            string cosS = costo.ToString();
            MessageBox.Show("Totale da pagare: "+costo+ "€");
            lB1.Items.Clear();
            foreach (Auto a in w)
            {
                lB1.Items.Add(a.Marca + "_" + a.Modello);
            }
        }
    }
}
