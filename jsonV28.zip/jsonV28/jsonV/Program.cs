﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace jsonV
{
    public static class Utente
    {
        public static string user;
        public static bool term = false;
    }
    internal static class Program
    {
        /// <summary>
        /// Punto di ingresso principale dell'applicazione.
        /// </summary>
        [STAThread]
        
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Autenticazione());
            if (Utente.term)
            {
                Application.Run(new Form1());
            }
        }
    }
}
