﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;

namespace jsonV
{
    public partial class Autenticazione : Form
    {
        class log
        {
            private string user;
            private string password;

            public string User
            {
                set { user = value; }
                get { return user; }
            }
            public string Psw
            {
                set { password = value; }
                get { return password; }
            }
        };

        List<log> l = new List<log>();

        bool var = false;
        public Autenticazione()
        {
            InitializeComponent();
            deserializza();
        }

        private void deserializza()
        {
            if (File.Exists("log.json"))
            {
                l.Clear();
                string[] righe = File.ReadAllLines("log.json");
                foreach (string riga in righe)
                {
                    log a = JsonSerializer.Deserialize<log>(riga);
                    l.Add(a);
                }
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ut = textBox1.Text;
            string ps = textBox2.Text;
            bool pres = false;

            foreach (log a in l)
            {
                if (ut == a.User && ps == a.Psw)
                {
                    Utente.user = a.User;
                    pres = true;
                    this.Close();
                    Utente.term = true;
                    break;
                }
            }
            if (pres == false)
            {
                MessageBox.Show("Username o password errati");
                textBox1.Text = "";
                textBox2.Text = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string us = textBox1.Text;
            string ps = textBox2.Text;
            log a = new log();
            a.User = us;
            a.Psw = ps;
            l.Add(a);

            string JsonString = string.Empty;
            string percorso = "log.json";
            int cont = 0;

            foreach (log a1 in l)
            {
                if (cont > 0)
                {
                    JsonString += Environment.NewLine;
                }
                JsonString += JsonSerializer.Serialize(a1);
                cont++;
            }

            File.WriteAllText(percorso, JsonString);

            textBox1.Text = "";
            textBox2.Text = "";
            label3_Click(sender, e);
        }

        private void label3_Click(object sender, EventArgs e)
        {
            if (var == false)
            {
                button1.Enabled = false;
                button1.Visible = false;
                button2.Enabled = true;
                button2.Visible = true;
                label3.Text = "Oppure Accedi";
                var = true;
            }
            else
            {
                button1.Enabled = true;
                button1.Visible = true;
                button2.Enabled = false;
                button2.Visible = false;
                label3.Text = "Oppure Registrati";
                var = false;
            }
        }
    }
}
